use bazifengshuisuanming;
set global optimizer_switch='derived_merge=OFF';


SET GLOBAL general_log = 'ON';
SET GLOBAL general_log_file = 'E:\\win7\\BareTailProfessional\\mysql.log';
SHOW VARIABLES LIKE "general_log%";